package com.zgmz.ls.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class RestClient {
    private ArrayList<String> servers = new ArrayList<String>();
    private String userName = null;
    private String passWord = null;

    private static String versionString = "v1";

    /*
    建立一个client
    param@serverUrl : config server的ip+port in String e.g. 127.0.0.1:8080,
    param@userName : 登陆太极使用的用户名
    param@passWord : 登陆太极使用的密码
     */
    public RestClient(String serverUrl, String userName, String passWord) {
        //mx: TODO contact config server to retrieve available servers
        servers.add(serverUrl);
        //
        this.userName = userName;
        this.passWord = passWord;
    }

    /*
    上传一个低保家庭信息(将写入太极)
    param@family : 低保家庭实例
    ret param@: rest请求返回结果
     */
    public RestResult UploadFamily(Family family) {
        try {
            //mx: TODO
            URL url = new URL("http://" + servers.get(0) + "/" + versionString + "/" + "users");

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            String input = family.ToJSONString();

            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

//            if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
//                throw new RuntimeException("Failed : HTTP error code : "
//                        + conn.getResponseCode());
//            }

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));

            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
                System.out.println(output);
            }

            conn.disconnect();

        } catch (MalformedURLException e) {

            e.printStackTrace();

        } catch (IOException e) {

            e.printStackTrace();

        }
        return null;
    }

    /*
    上传一个文件
    param@filePath : 文件将要上传到服务器上的路径
    param@fileContent : 文件内容(经过base64 encode)
    ret param@: rest请求返回结果
     */
    public RestResult UploadFile(String filePath, String fileContent) {
        return null;
    }


    /*
    查询上传进度
    param@requestId : UploadFamily返回结果中,后端提供的本次上传唯一标示
    ret param@: rest请求返回结果
     */
    public RestResult GetProgress(int requestId) {
        return null;
    }

    /*
    获得一条太极原始数据
    param@id : 申请人身份证号
    param@date : 救助年月, 格式为yyyyMM
    param@out : 获取结果
    ret param@: rest请求返回status code
     */
    public int GetFamilyFromTaiJi(String id, String date, Family out) {
        return 0;
    }
}
