package com.zgmz.ls.utils;

import java.util.ArrayList;

public class Family {
    public FamilyInfo fInfo; //家庭信息
    public CheckInfo cInfo; //核查信息
    public ArrayList<FamilyMember> cyxx; //成员信息
    public ArrayList<String> zmclxx; //证明材料信息

    public String ToJSONString() {
        return "{\"qty\":100,\"name\":\"iPad 4\"}";
    }
}
