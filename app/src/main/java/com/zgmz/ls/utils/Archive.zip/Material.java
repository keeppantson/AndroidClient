package com.zgmz.ls.utils;

public class Material {
    public String clmc; //材料名称
    public String cllx; //材料类型
    public String clxx; // 材料在服务器中的存储路径
}
