package com.zgmz.ls.utils;

import org.json.JSONObject;

/**
 * Created by mixiang on 2/21/17.
 */

public class RestResult {
    public int statusCode;
    public JSONObject body;
}
